function Navbar() {
    return <div style={{width:"100vw", height:"3rem", position:"absolute", top:"0", left:"0", textAlign:"left", paddingLeft:"2rem"}}>
        <div style={{display:"flex", alignItems:"center"}}>
            <img src="./logo.jpg" style={{height:"3rem", width: "3rem"}}></img>
            <h2 style={{marginLeft:"1rem"}}>PreSARS</h2>
        </div>
    </div>
}

export default Navbar